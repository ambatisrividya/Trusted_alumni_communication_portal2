import os
import secrets
import json 
import lmdb 
from datetime import datetime, date
from flask import Flask, render_template, request, redirect, url_for, session, flash, abort
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps

app = Flask(__name__)

# --- CONFIGURATION ---
session_secret = os.environ.get('SESSION_SECRET')
if not session_secret:
    # Use a fallback for local development if not set
    app.secret_key = 'super_secret_fallback_key' 
else:
    app.secret_key = session_secret

# CRITICAL FIX FOR 403 FORBIDDEN ERROR (Local HTTP)
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax' 
app.config['SESSION_COOKIE_SECURE'] = False 

# --- LMDB SETUP ---
# Database file path - using .lmdb extension for clarity
DB_PATH = os.environ.get('LMDB_PATH', './alumni_nexus.lmdb') 
LMDB_ENV = None

def get_db_env():
    """Initializes and returns the global LMDB environment."""
    global LMDB_ENV
    if LMDB_ENV is None:
        # Create LMDB environment with a generous map size (1GB) and max_dbs (1)
        LMDB_ENV = lmdb.open(DB_PATH.encode('utf-8'), map_size=1048576000, max_dbs=1, subdir=False)
    return LMDB_ENV

def serialize_data(data):
    """Converts a Python dictionary to JSON bytes for storage."""
    # Note: Datetime objects must be converted to strings before serializing
    data_copy = data.copy()
    for key, value in data_copy.items():
        if isinstance(value, (datetime, date)):
            data_copy[key] = value.isoformat()
    return json.dumps(data_copy).encode('utf-8')

def deserialize_data(data_bytes):
    """
    Converts bytes back to a Python dictionary. 
    Includes a critical fix to handle non-dictionary data (like counter integers).
    """
    if data_bytes is None:
        return None
    
    data = json.loads(data_bytes.decode('utf-8'))
    
    # CRITICAL FIX: Ensure the loaded data is a dictionary (all user/post data is a dict)
    if not isinstance(data, dict):
        return data 
    
    # Existing datetime conversion logic
    for key, value in data.items():
        if isinstance(value, str):
            try:
                # Check if it looks like a full timestamp (with T)
                if 'T' in value:
                    data[key] = datetime.fromisoformat(value)
                # Check if it looks like a date (no T)
                elif len(value.split('-')) == 3:
                    data[key] = date.fromisoformat(value)
            except (ValueError, TypeError):
                # Ignore if not a valid isoformat date/datetime
                pass
    return data

def get_next_id(key_name):
    """
    Retrieves and atomically increments the ID counter for a given key prefix.
    Uses its own isolated write transaction to avoid BadTxnError.
    """
    env = get_db_env()
    key = f'{key_name}_id_counter'.encode('utf-8')
    
    # Use a new, isolated transaction for the counter operation
    with env.begin(write=True) as txn:
        current_id_bytes = txn.get(key)
        # Ensure conversion to int is safe
        current_id = int(current_id_bytes.decode('utf-8')) if current_id_bytes and current_id_bytes.decode('utf-8').isdigit() else 1
        
        next_id = current_id + 1
        
        # Store the new next ID (atomically committing the increment)
        txn.put(key, str(next_id).encode('utf-8'))
        
    return current_id # Return the ID *just* generated

def init_db():
    """Initializes the database environment and ensures counters exist."""
    env = get_db_env()
    # Initialize counters if they don't exist
    with env.begin(write=True) as txn:
        # Counters for primary keys. Stored as bytes representing an integer.
        if not txn.get(b'ansa_user_id_counter'):
             txn.put(b'ansa_user_id_counter', b'1')
        if not txn.get(b'vanm_user_id_counter'):
             txn.put(b'vanm_user_id_counter', b'1')
        if not txn.get(b'announcement_id_counter'):
             txn.put(b'announcement_id_counter', b'1')
        if not txn.get(b'job_post_id_counter'):
             txn.put(b'job_post_id_counter', b'1')
        if not txn.get(b'application_id_counter'):
             txn.put(b'application_id_counter', b'1')

# --- LMDB HELPER FUNCTIONS FOR ROUTES ---

def get_all_by_prefix(prefix):
    """
    Retrieves all data items with a given key prefix, 
    skipping internal control keys like the ID counter.
    """
    env = get_db_env()
    results = []
    
    # Identify the key of the ID counter for this prefix
    counter_key = f'{prefix}_id_counter'.encode('utf-8')
    
    with env.begin() as txn:
        cursor = txn.cursor()
        
        # Move cursor to the first key with the given prefix
        if cursor.set_range(prefix.encode('utf-8')):
            for key, value in cursor.iternext(keys=True):
                # Stop iteration once prefix no longer matches
                if not key.startswith(prefix.encode('utf-8')):
                    break 
                
                # Skip the ID counter key (the cause of the previous error)
                if key == counter_key:
                    continue
                    
                # Only process keys that are actual data records (e.g., 'vanm_user:1', not 'vanm_user_id_counter')
                if b':' in key: 
                    results.append(deserialize_data(value))
    return results

def get_item_by_id(prefix, item_id):
    """Retrieves a single item by its ID."""
    env = get_db_env()
    key = f'{prefix}:{item_id}'.encode('utf-8')
    with env.begin() as txn:
        return deserialize_data(txn.get(key))

def put_item(prefix, item_id, data):
    """Stores a single item."""
    env = get_db_env()
    key = f'{prefix}:{item_id}'.encode('utf-8')
    with env.begin(write=True) as txn:
        txn.put(key, serialize_data(data))

def delete_item(prefix, item_id):
    """Deletes a single item."""
    env = get_db_env()
    key = f'{prefix}:{item_id}'.encode('utf-8')
    with env.begin(write=True) as txn:
        txn.delete(key)

def find_user_by_email(email, user_type):
    """Finds a user by email, relying on a dedicated index key."""
    env = get_db_env()
    email_key = f'{user_type}_email_to_id:{email}'.encode('utf-8')
    with env.begin() as txn:
        user_id_bytes = txn.get(email_key)
        if user_id_bytes:
            user_id = user_id_bytes.decode('utf-8')
            return get_item_by_id(f'{user_type}_user', user_id)
        return None

def find_ansa_user_by_employee_id(employee_id):
    """Finds an ANSA user by employee ID, relying on a dedicated index key."""
    env = get_db_env()
    emp_id_key = f'ansa_emp_id_to_id:{employee_id}'.encode('utf-8')
    with env.begin() as txn:
        user_id_bytes = txn.get(emp_id_key)
        if user_id_bytes:
            user_id = user_id_bytes.decode('utf-8')
            return get_item_by_id('ansa_user', user_id)
        return None

# --- AUTH DECORATORS & CSRF (Unchanged) ---
def generate_csrf_token():
    if '_csrf_token' not in session:
        session['_csrf_token'] = secrets.token_hex(32)
    return session['_csrf_token']

def validate_csrf_token():
    token = session.get('_csrf_token')
    form_token = request.form.get('_csrf_token')
    if not token or token != form_token:
        abort(403)

app.jinja_env.globals['csrf_token'] = generate_csrf_token

def ansa_login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'ansa_user_id' not in session:
            flash('Please login to access this page.', 'warning')
            return redirect(url_for('ansa_login'))
        return f(*args, **kwargs)
    return decorated_function

def vanm_login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'vanm_user_id' not in session:
            flash('Please login to access this page.', 'warning')
            return redirect(url_for('vanm_login'))
        return f(*args, **kwargs)
    return decorated_function

# --- ROUTES (REFRACTORED FOR LMDB) ---

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/ansa/signup', methods=['GET', 'POST'])
def ansa_signup():
    if request.method == 'POST':
        validate_csrf_token()
        # ... retrieve form data ...
        full_name = request.form['full_name']
        email = request.form['email']
        password = request.form['password']
        confirm_password = request.form['confirm_password']
        employee_id = request.form['employee_id']
        department = request.form['department']
        designation = request.form['designation']
        phone = request.form['phone']
        security_question = request.form['security_question']
        security_answer = request.form['security_answer']
        
        if password != confirm_password:
            flash('Passwords do not match!', 'danger')
            return redirect(url_for('ansa_signup'))
        
        # Check for unique email/ID manually
        if find_user_by_email(email, 'ansa'):
            flash('Email already registered!', 'danger')
            return redirect(url_for('ansa_signup'))
        if find_ansa_user_by_employee_id(employee_id):
            flash('Employee ID already exists!', 'danger')
            return redirect(url_for('ansa_signup'))
        
        password_hash = generate_password_hash(password)
        security_answer_hash = generate_password_hash(security_answer.lower())
        
        # FIX: Get ID outside the transaction that writes the user data
        ansa_user_id = get_next_id('ansa_user')
        
        env = get_db_env()
        with env.begin(write=True) as txn:
            user_data = {
                'id': str(ansa_user_id), # Store ID as string for consistency with keys
                'full_name': full_name,
                'email': email,
                'password_hash': password_hash,
                'employee_id': employee_id,
                'department': department,
                'designation': designation,
                'phone': phone,
                'security_question': security_question,
                'security_answer': security_answer_hash,
                'created_at': datetime.now(),
                'is_active': True
            }
            
            # Store primary record
            txn.put(f'ansa_user:{ansa_user_id}'.encode('utf-8'), serialize_data(user_data))
            
            # Store index keys for lookups
            txn.put(f'ansa_email_to_id:{email}'.encode('utf-8'), str(ansa_user_id).encode('utf-8'))
            txn.put(f'ansa_emp_id_to_id:{employee_id}'.encode('utf-8'), str(ansa_user_id).encode('utf-8'))

        flash('Registration successful! Please login.', 'success')
        return redirect(url_for('ansa_login'))
    
    return render_template('ansa/signup.html')

@app.route('/ansa/login', methods=['GET', 'POST'])
def ansa_login():
    if request.method == 'POST':
        validate_csrf_token()
        email = request.form['email']
        password = request.form['password']
        
        user = find_user_by_email(email, 'ansa')
        
        if user and user.get('is_active') and check_password_hash(user['password_hash'], password):
            session['ansa_user_id'] = user['id']
            session['ansa_user_name'] = user['full_name']
            session['user_type'] = 'ansa'
            flash(f'Welcome back, {user["full_name"]}!', 'success')
            return redirect(url_for('ansa_dashboard'))
        else:
            flash('Invalid email or password!', 'danger')
    
    return render_template('ansa/login.html')

@app.route('/ansa/logout')
def ansa_logout():
    session.clear()
    flash('You have been logged out successfully.', 'info')
    return redirect(url_for('index'))

@app.route('/ansa/dashboard')
@ansa_login_required
def ansa_dashboard():
    all_vanm_users = get_all_by_prefix('vanm_user')
    
    pending_count = sum(1 for user in all_vanm_users if not user.get('is_approved'))
    approved_count = sum(1 for user in all_vanm_users if user.get('is_approved'))
    
    all_jobs = get_all_by_prefix('job_post')
    jobs_count = sum(1 for job in all_jobs if job.get('is_active'))
    
    all_announcements = get_all_by_prefix('announcement')
    announcements_count = sum(1 for ann in all_announcements if ann.get('is_active'))
    
    return render_template('ansa/dashboard.html', 
                         pending_count=pending_count,
                         approved_count=approved_count,
                         jobs_count=jobs_count,
                         announcements_count=announcements_count)

@app.route('/ansa/pending-registrations')
@ansa_login_required
def ansa_pending_registrations():
    all_vanm_users = get_all_by_prefix('vanm_user')
    pending_users = sorted([user for user in all_vanm_users if not user.get('is_approved')], 
                           key=lambda x: x['created_at'], reverse=True)
    return render_template('ansa/pending_registrations.html', pending_users=pending_users)

@app.route('/ansa/approve-user/<string:user_id>', methods=['POST'])
@ansa_login_required
def ansa_approve_user(user_id):
    validate_csrf_token()
    user = get_item_by_id('vanm_user', user_id)
    if user:
        user['is_approved'] = True
        put_item('vanm_user', user_id, user)
        flash('User approved successfully!', 'success')
    return redirect(url_for('ansa_pending_registrations'))

@app.route('/ansa/reject-user/<string:user_id>', methods=['POST'])
@ansa_login_required
def ansa_reject_user(user_id):
    validate_csrf_token()
    # In LMDB, we must ensure the user is not approved before deletion
    user = get_item_by_id('vanm_user', user_id)
    if user and not user.get('is_approved'):
        delete_item('vanm_user', user_id)
        
        # Also need to remove the email index key
        env = get_db_env()
        email_key = f'vanm_email_to_id:{user["email"]}'.encode('utf-8')
        with env.begin(write=True) as txn:
            txn.delete(email_key)
        
        flash('User registration rejected.', 'info')
    return redirect(url_for('ansa_pending_registrations'))

@app.route('/ansa/member-directory')
@ansa_login_required
def ansa_member_directory():
    search = request.args.get('search', '')
    all_vanm_users = get_all_by_prefix('vanm_user')
    
    members = [user for user in all_vanm_users if user.get('is_approved') and user.get('is_active')]
    
    if search:
        search_lower = search.lower()
        members = [
            m for m in members if (
                search_lower in m.get('full_name', '').lower() or
                search_lower in m.get('current_company', '').lower() or
                search_lower in m.get('major', '').lower()
            )
        ]
        
    # Sort manually in Python as LMDB keys don't guarantee full-name sort order
    members.sort(key=lambda x: x['full_name'])
    
    return render_template('ansa/member_directory.html', members=members, search=search)

@app.route('/ansa/announcements', methods=['GET', 'POST'])
@ansa_login_required
def ansa_announcements():
    env = get_db_env()
    
    if request.method == 'POST':
        validate_csrf_token()
        title = request.form['title']
        content = request.form['content']
        priority = request.form['priority']
        
        # FIX: Get ID outside the transaction that writes the announcement data
        ann_id = get_next_id('announcement')
        
        with env.begin(write=True) as txn:
            announcement_data = {
                'id': str(ann_id),
                'title': title,
                'content': content,
                'priority': priority,
                'created_by': session['ansa_user_id'],
                'created_at': datetime.now(),
                'is_active': True
            }
            # Use direct transaction put
            txn.put(f'announcement:{ann_id}'.encode('utf-8'), serialize_data(announcement_data))
        
        flash('Announcement posted successfully!', 'success')
        return redirect(url_for('ansa_announcements'))
    
    announcements = get_all_by_prefix('announcement')
    active_announcements = sorted([ann for ann in announcements if ann.get('is_active')], 
                                 key=lambda x: x['created_at'], reverse=True)
    
    # Manually fetch author names
    ansa_users = {user['id']: user['full_name'] for user in get_all_by_prefix('ansa_user')}
    for ann in active_announcements:
        ann['author_name'] = ansa_users.get(ann['created_by'], 'Unknown Admin')
        
    return render_template('ansa/announcements.html', announcements=active_announcements)

@app.route('/ansa/delete-announcement/<string:ann_id>', methods=['POST'])
@ansa_login_required
def ansa_delete_announcement(ann_id):
    validate_csrf_token()
    ann = get_item_by_id('announcement', ann_id)
    if ann:
        ann['is_active'] = False
        put_item('announcement', ann_id, ann)
        flash('Announcement deleted.', 'info')
    return redirect(url_for('ansa_announcements'))

@app.route('/ansa/analytics')
@ansa_login_required
def ansa_analytics():
    all_vanm_users = get_all_by_prefix('vanm_user')
    approved_members = [u for u in all_vanm_users if u.get('is_approved')]
    
    total_members = len(approved_members)
    pending_members = sum(1 for u in all_vanm_users if not u.get('is_approved'))
    
    # Calculate year, degree, and country stats (Manual Grouping)
    year_stats = {}
    degree_stats = {}
    country_stats = {}
    
    for member in approved_members:
        # Year Stats
        year = str(member.get('graduation_year'))
        if year != 'None':
            year_stats[year] = year_stats.get(year, 0) + 1
        
        # Degree Stats
        degree = member.get('degree')
        if degree:
            degree_stats[degree] = degree_stats.get(degree, 0) + 1
            
        # Country Stats
        country = member.get('country')
        if country:
            country_stats[country] = country_stats.get(country, 0) + 1
            
    # Convert to list of dicts for template and sort
    year_stats = sorted([{'graduation_year': y, 'count': c} for y, c in year_stats.items()], key=lambda x: x['graduation_year'], reverse=True)[:10]
    degree_stats = sorted([{'degree': d, 'count': c} for d, c in degree_stats.items()], key=lambda x: x['count'], reverse=True)
    country_stats = sorted([{'country': c, 'count': cnt} for c, cnt in country_stats.items()], key=lambda x: x['count'], reverse=True)[:10]

    all_jobs = get_all_by_prefix('job_post')
    active_jobs = sum(1 for job in all_jobs if job.get('is_active'))
    
    total_applications = len(get_all_by_prefix('application'))
    
    return render_template('ansa/analytics.html',
                         total_members=total_members,
                         pending_members=pending_members,
                         year_stats=year_stats,
                         degree_stats=degree_stats,
                         country_stats=country_stats,
                         active_jobs=active_jobs,
                         total_applications=total_applications)

@app.route('/ansa/job-postings', methods=['GET', 'POST'])
@ansa_login_required
def ansa_job_postings():
    env = get_db_env()
    
    if request.method == 'POST':
        validate_csrf_token()
        title = request.form['title']
        company = request.form['company']
        location = request.form['location']
        job_type = request.form['job_type']
        description = request.form['description']
        requirements = request.form['requirements']
        salary_range = request.form['salary_range']
        contact_email = request.form['contact_email']
        deadline_str = request.form['deadline']
        
        deadline = date.fromisoformat(deadline_str) if deadline_str else None
        
        # FIX: Get ID outside the transaction that writes the job post data
        job_id = get_next_id('job_post') 
        
        # This transaction is now dedicated to writing the job record only.
        with env.begin(write=True) as txn:
            job_data = {
                'id': str(job_id),
                'title': title,
                'company': company,
                'location': location,
                'job_type': job_type,
                'description': description,
                'requirements': requirements,
                'salary_range': salary_range,
                'contact_email': contact_email,
                'posted_by': session['ansa_user_id'],
                'created_at': datetime.now(),
                'deadline': deadline,
                'is_active': True
            }
            # Use direct transaction put
            txn.put(f'job_post:{job_id}'.encode('utf-8'), serialize_data(job_data))
        
        flash('Job posting created successfully!', 'success')
        return redirect(url_for('ansa_job_postings'))
    
    jobs = get_all_by_prefix('job_post')
    active_jobs = sorted([job for job in jobs if job.get('is_active')], 
                         key=lambda x: x['created_at'], reverse=True)
    
    # Manually fetch posted by name and application count
    ansa_users = {user['id']: user['full_name'] for user in get_all_by_prefix('ansa_user')}
    job_applications = get_all_by_prefix('application')
    
    application_counts = {}
    for app in job_applications:
        job_id = str(app['job_id'])
        application_counts[job_id] = application_counts.get(job_id, 0) + 1
        
    for job in active_jobs:
        job['posted_by_name'] = ansa_users.get(job['posted_by'], 'Unknown Admin')
        job['application_count'] = application_counts.get(str(job['id']), 0)
        
    return render_template('ansa/job_postings.html', jobs=active_jobs)

@app.route('/ansa/delete-job/<string:job_id>', methods=['POST'])
@ansa_login_required
def ansa_delete_job(job_id):
    validate_csrf_token()
    job = get_item_by_id('job_post', job_id)
    if job:
        job['is_active'] = False
        put_item('job_post', job_id, job)
        flash('Job posting removed.', 'info')
    return redirect(url_for('ansa_job_postings'))

@app.route('/vanm/signup', methods=['GET', 'POST'])
def vanm_signup():
    if request.method == 'POST':
        validate_csrf_token()
        # ... retrieve form data ...
        full_name = request.form['full_name']
        email = request.form['email']
        password = request.form['password']
        confirm_password = request.form['confirm_password']
        graduation_year = request.form['graduation_year']
        degree = request.form['degree']
        major = request.form['major']
        current_company = request.form.get('current_company', '')
        current_position = request.form.get('current_position', '')
        phone = request.form['phone']
        linkedin_url = request.form.get('linkedin_url', '')
        city = request.form.get('city', '')
        country = request.form.get('country', '')
        bio = request.form.get('bio', '')
        skills = request.form.get('skills', '')
        
        if password != confirm_password:
            flash('Passwords do not match!', 'danger')
            return redirect(url_for('vanm_signup'))
        
        # Check for unique email manually
        if find_user_by_email(email, 'vanm'):
            flash('Email already registered!', 'danger')
            return redirect(url_for('vanm_signup'))
        
        password_hash = generate_password_hash(password)
        
        # FIX: Get ID outside the transaction that writes the user data
        vanm_user_id = get_next_id('vanm_user')
        
        env = get_db_env()
        with env.begin(write=True) as txn:
            user_data = {
                'id': str(vanm_user_id),
                'full_name': full_name,
                'email': email,
                'password_hash': password_hash,
                'graduation_year': int(graduation_year),
                'degree': degree,
                'major': major, 
                'current_company': current_company,
                'current_position': current_position,
                'phone': phone,
                'linkedin_url': linkedin_url,
                'city': city,
                'country': country,
                'bio': bio,
                'skills': skills,
                'is_approved': False,
                'created_at': datetime.now(),
                'is_active': True
            }
            
            # Store primary record
            txn.put(f'vanm_user:{vanm_user_id}'.encode('utf-8'), serialize_data(user_data))
            
            # Store index key for email lookup
            txn.put(f'vanm_email_to_id:{email}'.encode('utf-8'), str(vanm_user_id).encode('utf-8'))
        
        flash('Registration submitted! Please wait for admin approval.', 'success')
        return redirect(url_for('vanm_login'))
    
    return render_template('vanm/signup.html')

@app.route('/vanm/login', methods=['GET', 'POST'])
def vanm_login():
    if request.method == 'POST':
        validate_csrf_token()
        email = request.form['email']
        password = request.form['password']
        
        user = find_user_by_email(email, 'vanm')
        
        if user and user.get('is_active') and check_password_hash(user['password_hash'], password):
            if not user.get('is_approved'):
                flash('Your account is pending approval. Please wait for admin verification.', 'warning')
                return redirect(url_for('vanm_login'))
            
            session['vanm_user_id'] = user['id']
            session['vanm_user_name'] = user['full_name']
            session['user_type'] = 'vanm'
            flash(f'Welcome back, {user["full_name"]}!', 'success')
            return redirect(url_for('vanm_dashboard'))
        else:
            flash('Invalid email or password!', 'danger')
    
    return render_template('vanm/login.html')

@app.route('/vanm/logout')
def vanm_logout():
    session.clear()
    flash('You have been logged out successfully.', 'info')
    return redirect(url_for('index'))

@app.route('/vanm/dashboard')
@vanm_login_required
def vanm_dashboard():
    user = get_item_by_id('vanm_user', session['vanm_user_id'])
    
    announcements = get_all_by_prefix('announcement')
    active_announcements = sorted([ann for ann in announcements if ann.get('is_active')], 
                                 key=lambda x: x['created_at'], reverse=True)[:5]
    
    all_jobs = get_all_by_prefix('job_post')
    jobs_count = sum(1 for job in all_jobs if job.get('is_active'))
    
    all_vanm_users = get_all_by_prefix('vanm_user')
    members_count = sum(1 for u in all_vanm_users if u.get('is_approved'))
    
    return render_template('vanm/dashboard.html', 
                         user=user, 
                         announcements=active_announcements,
                         jobs_count=jobs_count,
                         members_count=members_count)

@app.route('/vanm/profile', methods=['GET', 'POST'])
@vanm_login_required
def vanm_profile():
    user_id = session['vanm_user_id']
    
    if request.method == 'POST':
        validate_csrf_token()
        
        user = get_item_by_id('vanm_user', user_id)
        if user:
            # Update fields
            user['current_company'] = request.form.get('current_company', '')
            user['current_position'] = request.form.get('current_position', '')
            user['phone'] = request.form['phone']
            user['linkedin_url'] = request.form.get('linkedin_url', '')
            user['city'] = request.form.get('city', '')
            user['country'] = request.form.get('country', '')
            user['bio'] = request.form.get('bio', '')
            user['skills'] = request.form.get('skills', '')
            
            put_item('vanm_user', user_id, user)
            flash('Profile updated successfully!', 'success')
            return redirect(url_for('vanm_profile'))
        
    user = get_item_by_id('vanm_user', user_id)
    return render_template('vanm/profile.html', user=user)

@app.route('/vanm/alumni-directory')
@vanm_login_required
def vanm_alumni_directory():
    search = request.args.get('search', '')
    year_filter = request.args.get('year', '')
    
    all_vanm_users = get_all_by_prefix('vanm_user')
    
    alumni = [user for user in all_vanm_users if user.get('is_approved') and user.get('is_active')]
    
    # Filtering logic
    if search:
        search_lower = search.lower()
        alumni = [
            m for m in alumni if (
                search_lower in m.get('full_name', '').lower() or
                search_lower in m.get('current_company', '').lower() or
                search_lower in m.get('major', '').lower() or
                search_lower in m.get('city', '').lower()
            )
        ]
        
    if year_filter:
        try:
            year_filter_int = int(year_filter)
            alumni = [m for m in alumni if m.get('graduation_year') == year_filter_int]
        except ValueError:
            pass # Ignore invalid year filter
        
    alumni.sort(key=lambda x: x['full_name'])
    
    years = sorted(list(set(m['graduation_year'] for m in alumni if m.get('graduation_year'))), reverse=True)
    
    return render_template('vanm/alumni_directory.html', 
                           alumni=alumni, 
                           search=search, 
                           year_filter=year_filter, 
                           years=years)

@app.route('/vanm/career-opportunities')
@vanm_login_required
def vanm_career_opportunities():
    jobs = get_all_by_prefix('job_post')
    active_jobs = sorted([job for job in jobs if job.get('is_active')], 
                         key=lambda x: x['created_at'], reverse=True)
    
    applications = get_all_by_prefix('application')
    
    # Check which jobs the current user has applied for
    user_applied_job_ids = {str(app['job_id']) for app in applications if str(app['applicant_id']) == session['vanm_user_id']}
    
    for job in active_jobs:
        job['has_applied'] = job['id'] in user_applied_job_ids
    
    return render_template('vanm/career_opportunities.html', jobs=active_jobs)

@app.route('/vanm/apply-job/<string:job_id>', methods=['POST'])
@vanm_login_required
def vanm_apply_job(job_id):
    validate_csrf_token()
    cover_letter = request.form.get('cover_letter', '')
    applicant_id = session['vanm_user_id']
    
    # Check if application already exists (Manual Query)
    applications = get_all_by_prefix('application')
    existing = next((app for app in applications if str(app['job_id']) == job_id and str(app['applicant_id']) == applicant_id), None)
    
    if existing:
        flash('You have already applied for this position.', 'warning')
    else:
        # FIX: Get ID outside the transaction that writes the application data
        application_id = get_next_id('application')
        
        env = get_db_env()
        with env.begin(write=True) as txn:
            application_data = {
                'id': str(application_id),
                'job_id': job_id,
                'applicant_id': applicant_id,
                'cover_letter': cover_letter,
                'applied_at': datetime.now(),
                'status': 'pending'
            }
            # Use direct transaction put
            txn.put(f'application:{application_id}'.encode('utf-8'), serialize_data(application_data))
        
        flash('Application submitted successfully!', 'success')
    
    return redirect(url_for('vanm_career_opportunities'))

# Execute database initialization in the application context
with app.app_context():
    init_db()

if __name__ == '__main__':
    # Flask default debug mode is false, set FLASK_DEBUG=true in environment to enable
    debug_mode = os.environ.get('FLASK_DEBUG', 'false').lower() == 'true'
    app.run(host='0.0.0.0', port=5000, debug=debug_mode)